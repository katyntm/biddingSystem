import AppRouter from './router'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'

function App(){
  return (
      <AppRouter/>
  )
}

export default App;
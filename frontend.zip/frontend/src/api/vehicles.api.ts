import { useQuery } from '@tanstack/react-query';
import { getVehicleByIdApi, getVehiclesApi } from '../hooks/useVehicles';

export const useVehicles = () => {
  return useQuery({
    queryKey: ['vehicles'],
    queryFn: getVehiclesApi,
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 2,
  });
};

export const useVehicle = (id: string) => {
  return useQuery({
    queryKey: ['vehicle', id],
    queryFn: () => getVehicleByIdApi(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
  });
};
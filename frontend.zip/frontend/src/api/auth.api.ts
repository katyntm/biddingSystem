import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { loginApi } from '../hooks/useAuth';
import { removeTokens, setAccessToken, setEmail, setUserName } from '../shared/utils/auth';
import { toast } from 'react-toastify';

export const useLogin = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: loginApi,
    onSuccess: (data) => {
      // Store tokens and user info
      setAccessToken(data.accessToken);
      setUserName(data.user.username);
      setEmail(data.user.email);

      // Clear any existing queries
      queryClient.clear();

      toast.success('Login successful!');
      navigate('/reports/purchases');
    },
    onError: (error: { response?: { data?: { message?: string } } }) => {
      console.error('Login failed:', error);
      const errorMessage =
        error?.response?.data?.message || 'Login failed. Please check your credentials.';
      toast.error(errorMessage);
    },
  });
};

export const useLogout = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  return () => {
    removeTokens();
    queryClient.clear();
    navigate('/auth/login');
    toast.info('You have been logged out.');
  };
};
﻿namespace CarAuction.Infrastructure.Mock
{
    public class VehicleImage1
    {
        public Guid Id { get; set; }
        public Guid VehicleId { get; set; }
        public string Url { get; set; }
        public DateTime CreatedAt { get; set; }
        //FK
        public Vehicle1 Vehicle { get; set; }
    }
}

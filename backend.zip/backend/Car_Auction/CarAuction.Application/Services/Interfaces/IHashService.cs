﻿namespace CarAuction.Application.Interfaces.HashService
{
    public interface IHashService
    {
       string ComputeMD5(string input);
    }
}

﻿using CarAuction.Domain.Entities;

namespace CarAuction.Domain.Interfaces
{
    public interface ICriteriaRepository : IGenericRepository<Criteria>
    {
    }
}

﻿using CarAuction.Domain.Entities;

namespace CarAuction.Domain.Interfaces
{
    public  interface IAuctionVehicleRepository : IGenericRepository<AuctionVehicle>
    {
    }
}

﻿namespace CarAuction.Domain.Enums
{
    public enum  CreditStatus
    {
        Active,
        Inactive
    }
}

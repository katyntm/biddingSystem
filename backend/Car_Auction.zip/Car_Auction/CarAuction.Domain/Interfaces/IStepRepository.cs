﻿using CarAuction.Domain.Entities;

namespace CarAuction.Domain.Interfaces
{
    public interface IStepRepository : IGenericRepository<Step>
    {
    }
}

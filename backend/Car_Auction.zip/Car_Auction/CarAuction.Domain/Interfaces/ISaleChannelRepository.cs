﻿using CarAuction.Domain.Entities;

namespace CarAuction.Domain.Interfaces
{
    public interface ISaleChannelRepository : IGenericRepository<SaleChannel>
    {
    }
}
